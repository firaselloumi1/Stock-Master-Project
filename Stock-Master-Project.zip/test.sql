-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 21 jan. 2023 à 19:17
-- Version du serveur : 10.4.27-MariaDB
-- Version de PHP : 8.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `ID_Admin` int(11) NOT NULL,
  `Name_Admin` varchar(30) DEFAULT NULL,
  `E_mail` varchar(30) DEFAULT NULL,
  `Phone` int(11) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`ID_Admin`, `Name_Admin`, `E_mail`, `Phone`, `Password`) VALUES
(5325883, 'David L. Hall', 'DavidLHall@teleworm.us', 890384201, '10001000'),
(63135222, 'David V. James', 'DavidVJames@jourrapide.com', 386903266, '20002000'),
(98617584, 'John L. Taylor', 'JohnLTaylor@dayrep.com', 883445191, '30003000');

-- --------------------------------------------------------

--
-- Structure de la table `availableproduct`
--

CREATE TABLE `availableproduct` (
  `ID_Product` int(11) NOT NULL,
  `Name_Product` varchar(30) DEFAULT NULL,
  `Price` int(11) NOT NULL,
  `Max_Qty` int(11) DEFAULT NULL,
  `Min_Qty` int(11) DEFAULT NULL,
  `Production_Date` date DEFAULT NULL,
  `Last_Consumption_Date` date DEFAULT NULL,
  `Qty_Received` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Qty_Sent` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `Qty_Available` int(11) GENERATED ALWAYS AS (`Qty_Received` - `Qty_Sent` - `Qty_Defective` + `Qty_Returned`) VIRTUAL,
  `Order_Status` varchar(10) GENERATED ALWAYS AS (case when `Qty_Available` <= `Min_Qty` then 'Order' when `Qty_Available` > `Min_Qty` then 'NO_Order' end) VIRTUAL,
  `Qty_Defective` int(10) UNSIGNED NOT NULL DEFAULT current_timestamp(),
  `Qty_Returned` int(3) NOT NULL DEFAULT 0,
  `Qty_To_Order` int(5) GENERATED ALWAYS AS (`Max_Qty` - `Qty_Available`) VIRTUAL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `availableproduct`
--

INSERT INTO `availableproduct` (`ID_Product`, `Name_Product`, `Price`, `Max_Qty`, `Min_Qty`, `Production_Date`, `Last_Consumption_Date`, `Qty_Received`, `Qty_Sent`, `Qty_Defective`, `Qty_Returned`) VALUES
(454777, 'Doritos', 11, 1000, 200, '2022-03-11', '2023-03-11', 1000, 750, 5, 0),
(4414065, 'M&M\'s', 4, 1500, 200, '2022-01-17', '2023-01-17', 1500, 1000, 0, 0),
(9891343, 'Lay\'s Chips', 10, 1000, 200, '2022-04-22', '2023-04-22', 1000, 750, 0, 0),
(14501455, 'Planters', 6, 500, 100, '2022-03-24', '2024-03-24', 500, 400, 0, 0),
(18989005, 'Jif', 9, 500, 100, '2022-04-14', '2025-04-14', 500, 200, 0, 0),
(33019053, 'Campbell\'s', 3, 500, 100, '2022-10-11', '2024-10-11', 750, 400, 0, 0),
(34087346, 'Pringles', 7, 1000, 200, '2022-05-09', '2024-05-09', 1000, 800, 0, 0),
(41780982, 'Fritos', 6, 1000, 200, '2022-05-20', '2025-05-20', 1000, 600, 0, 0),
(41902289, 'Oreo Cookies', 10, 1000, 200, '2022-02-07', '2025-02-07', 1000, 800, 10, 5),
(42265310, 'Reese\'s', 6, 1500, 200, '2022-02-04', '2024-02-04', 1500, 700, 0, 0),
(44076538, 'Nestlé Toll House', 11, 750, 150, '2022-09-12', '2023-09-12', 750, 700, 0, 0),
(45889428, 'Tostitos', 4, 500, 100, '2022-08-30', '2024-08-30', 500, 400, 0, 0),
(64441122, 'Ritz', 10, 1000, 200, '2022-02-22', '2023-02-22', 1000, 500, 0, 0),
(68861817, 'Cheerios', 5, 500, 100, '2022-06-15', '2023-06-15', 500, 440, 0, 5),
(71513137, 'Hershey\'s', 10, 1500, 200, '2022-02-01', '2023-02-01', 1500, 950, 0, 0),
(82888380, 'Quaker', 2, 500, 100, '2022-09-02', '2025-09-02', 500, 200, 0, 0),
(87053266, 'Dove', 4, 1500, 200, '2022-09-09', '2023-09-09', 1500, 500, 0, 0),
(89858255, 'Pillsbury', 1, 1000, 200, '2022-02-16', '2023-02-16', 1000, 480, 0, 0),
(96854656, 'Snickers', 2, 1500, 200, '2022-06-21', '2023-06-21', 1500, 400, 0, 0),
(97572045, 'Betty Crocker', 17, 750, 150, '2022-04-19', '2023-04-19', 750, 500, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `check_defective`
--

CREATE TABLE `check_defective` (
  `ID_Worker` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL,
  `Check_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `check_defective`
--

INSERT INTO `check_defective` (`ID_Worker`, `ID_Product`, `Check_Date`) VALUES
(37917433, 41902289, '2022-04-27'),
(72437083, 454777, '2022-06-10');

-- --------------------------------------------------------

--
-- Structure de la table `check_return`
--

CREATE TABLE `check_return` (
  `ID_Worker` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL,
  `Check_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `check_return`
--

INSERT INTO `check_return` (`ID_Worker`, `ID_Product`, `Check_Date`) VALUES
(38819093, 68861817, '2022-05-12'),
(72437083, 41902289, '2022-07-22');

-- --------------------------------------------------------

--
-- Structure de la table `contract`
--

CREATE TABLE `contract` (
  `ID_Admin` int(11) NOT NULL,
  `ID_Worker` int(11) NOT NULL,
  `Salary` int(11) DEFAULT NULL,
  `Length` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `contract`
--

INSERT INTO `contract` (`ID_Admin`, `ID_Worker`, `Salary`, `Length`) VALUES
(5325883, 12534947, 2500, 2),
(5325883, 14647132, 2500, 2),
(5325883, 21072972, 3000, 3),
(5325883, 96558639, 3000, 3),
(63135222, 36084308, 2500, 2),
(63135222, 37917433, 2500, 2),
(63135222, 38819093, 3000, 3),
(98617584, 64975793, 3000, 3),
(98617584, 72437083, 4000, 5),
(98617584, 77395878, 5000, 5);

-- --------------------------------------------------------

--
-- Structure de la table `customer`
--

CREATE TABLE `customer` (
  `ID_Customer` int(11) NOT NULL,
  `Name_Customer` varchar(30) DEFAULT NULL,
  `Phone` int(11) DEFAULT NULL,
  `Adress` varchar(30) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL,
  `Password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `customer`
--

INSERT INTO `customer` (`ID_Customer`, `Name_Customer`, `Phone`, `Adress`, `Email`, `Password`) VALUES
(2724057, 'David L. Johnson', 261610035, '72 Blairgowrie Avenue MYALLA N', 'Davidjohnson@gmail.com', 'Davidjohnson'),
(5020214, 'Jules D. Apodaca', 333233149, '65 Myrtle Street NILLAHCOOTIE ', 'JulesApodaca@gmail.com', 'Julesapodaca'),
(9687379, 'Thomas A. Edwards', 745825545, '24 Hodgson St LOCH LOMOND QLD ', 'Thomasedwards@gmail.com', 'Thomasedwards'),
(14089742, 'Thomas M. Schuyler', 267538287, '5 Prince Street WHITEMAN CREEK', 'Thomasschuyler@gmail.com', 'Thomasschuyler'),
(24667219, 'Justin C. Hunt', 362932776, '11 Mildura Street LAUNCESTON T', 'Justinhunt@gmail.com', 'Justinhunt'),
(27198160, 'Gordon W. Matthews', 353274099, '45 Crofts Road TUBBUT VIC 3888', 'Gordonmatthews@gmail.com', 'Gordonmatthews'),
(28601663, 'Donnie C. Trejo', 740450603, '52 Glen William Road FITZROY I', 'Donnietrejo@gmail.com', 'Donnietrejo'),
(50322196, 'Harold M. Lambdin', 745456136, '70 McLaughlin Road WANORA QLD ', 'Haroldlambdin@gmail.com', 'Haroldlambdin'),
(54932503, 'Richard D. Velez', 740407336, '34 Banksia Court WEST POINT QL', 'Richardvelez@gmail.com', 'Richardvelez'),
(57309244, 'Benjamin E. Battle', 393579098, '81 Boughtman Street HOPETOUN G', 'Benjaminbattle@gmail.com', 'Benjaminbattle'),
(68314507, 'Jonathan D. Nees', 240916865, '57 Ulomogo Street OAKDENE NSW ', 'Jonathannees@gmail.com', 'Jonathannees'),
(74577058, 'Charles C. Hay', 749964974, '59 Gralow Court BLACKS BEACH Q', 'Charleshay@gmail.com', 'Charleshay'),
(83069993, 'Erick K. Burgess', 745264054, '63 Goldfields Road COALBANK QL', 'Erickburgess@gmail.com', 'Erickburgess'),
(92937243, 'Thomas M. Mowery', 740542552, '96 Passage Avenue PORT DOUGLAS', 'Thomasmowery@gmail.com', 'Thomasmowery'),
(96991843, 'Ian M. Wong', 267558859, '20 Nandewar Street JOLLY NOSE ', 'Ianwong@gmail.com', 'Ianwong');

-- --------------------------------------------------------

--
-- Structure de la table `customer_reception`
--

CREATE TABLE `customer_reception` (
  `ID_Customer` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL,
  `RDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `customer_reception`
--

INSERT INTO `customer_reception` (`ID_Customer`, `ID_Product`, `RDate`) VALUES
(2724057, 68861817, '2022-10-20'),
(2724057, 89858255, '2023-01-31'),
(5020214, 71513137, '2022-12-14'),
(9687379, 5616398, '2022-12-14'),
(14089742, 4414065, '2022-12-29'),
(24667219, 18989005, '2022-12-23'),
(27198160, 454777, '2022-11-18'),
(27198160, 82888380, '2023-02-10'),
(28601663, 14501455, '2023-02-02'),
(28601663, 75174929, '2022-10-31'),
(50322196, 42265310, '2023-03-07'),
(50322196, 87053266, '2022-11-23'),
(54932503, 20190965, '2022-12-29'),
(54932503, 45889428, '2023-03-07'),
(57309244, 44076538, '2023-01-05'),
(57309244, 97572045, '2022-10-14'),
(68314507, 33767078, '2022-11-29'),
(68314507, 96854656, '2023-03-16'),
(74577058, 33019053, '0000-00-00'),
(74577058, 41902289, '2023-01-18'),
(83069993, 34087346, '2023-02-09'),
(83069993, 67817617, '2022-11-16'),
(92937243, 9891343, '2022-12-23'),
(96991843, 41780982, '2022-11-25'),
(96991843, 64441122, '2023-03-13');

-- --------------------------------------------------------

--
-- Structure de la table `defective`
--

CREATE TABLE `defective` (
  `ID_Product` int(11) NOT NULL,
  `Name_Product` varchar(30) DEFAULT NULL,
  `Defectiveness` varchar(30) DEFAULT NULL,
  `Defective_Qty` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `defective`
--

INSERT INTO `defective` (`ID_Product`, `Name_Product`, `Defectiveness`, `Defective_Qty`) VALUES
(454777, 'Doritos', 'Low Weight', 5),
(41902289, 'Oreo Cookies', 'Broken', 10);

-- --------------------------------------------------------

--
-- Structure de la table `entering_stock`
--

CREATE TABLE `entering_stock` (
  `Id_Stock` int(11) NOT NULL,
  `Id_Product` int(11) DEFAULT NULL,
  `Quantity_In` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `entering_stock`
--

INSERT INTO `entering_stock` (`Id_Stock`, `Id_Product`, `Quantity_In`) VALUES
(1, 97572045, 750),
(2, 33019053, 750),
(3, 68861817, 500),
(6, 454777, 1000),
(7, 87053266, 1500),
(8, 41780982, 1000),
(10, 71513137, 1500),
(11, 18989005, 500),
(12, 64441122, 1000),
(14, 45889428, 500),
(15, 9891343, 1000),
(16, 4414065, 1500),
(17, 44076538, 750),
(18, 41902289, 1000),
(19, 89858255, 1000),
(20, 14501455, 500),
(21, 34087346, 1000),
(22, 82888380, 500),
(23, 42265310, 1500),
(25, 96854656, 1500);

-- --------------------------------------------------------

--
-- Structure de la table `feedback`
--

CREATE TABLE `feedback` (
  `Customer_ID` int(11) DEFAULT NULL,
  `Customer_Name` varchar(255) DEFAULT NULL,
  `Feedback` varchar(255) DEFAULT NULL,
  `Request` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structure de la table `intward`
--

CREATE TABLE `intward` (
  `ID_Product` int(11) NOT NULL,
  `Name_Product` varchar(30) DEFAULT NULL,
  `Qty_Received` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `intward`
--

INSERT INTO `intward` (`ID_Product`, `Name_Product`, `Qty_Received`) VALUES
(454777, 'Doritos', 1000),
(4414065, 'M&M\'s', 1500),
(5616398, 'Kit Kat', 1500),
(9891343, 'Lay\'s Chips', 1000),
(14501455, 'Planters', 500),
(18989005, 'Jif', 500),
(20190965, 'Kellogg\'s', 500),
(33019053, 'Campbell\'s', 500),
(33767078, 'Ghirardelli', 1500),
(34087346, 'Pringles', 1000),
(41780982, 'Fritos', 1000),
(41902289, 'Oreo Cookies', 1000),
(42265310, 'Reese\'s', 1500),
(44076538, 'Nestlé Toll House', 750),
(45889428, 'Tostitos', 500),
(64441122, 'Ritz', 1000),
(67817617, 'Cheez-It', 1000),
(68861817, 'Cheerios', 500),
(71513137, 'Hershey\'s', 1500),
(75174929, 'Cheetos', 1000),
(82888380, 'Quaker', 500),
(87053266, 'Dove', 1500),
(89858255, 'Pillsbury', 1000),
(96854656, 'Snickers', 1500),
(97572045, 'Betty Crocker', 750);

-- --------------------------------------------------------

--
-- Structure de la table `inventory`
--

CREATE TABLE `inventory` (
  `ID_Inventory` int(11) NOT NULL,
  `Name_Inventory` varchar(30) DEFAULT NULL,
  `Location` varchar(30) DEFAULT NULL,
  `Size` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `inventory`
--

INSERT INTO `inventory` (`ID_Inventory`, `Name_Inventory`, `Location`, `Size`) VALUES
(1, 'Inventory1', 'Hammamet', 10000),
(2, 'ExtraInventory', 'Carthage', 5000);

-- --------------------------------------------------------

--
-- Structure de la table `in_stock`
--

CREATE TABLE `in_stock` (
  `id_stock` int(11) NOT NULL,
  `id_product` int(11) DEFAULT NULL,
  `Qty_Available` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `in_stock`
--

INSERT INTO `in_stock` (`id_stock`, `id_product`, `Qty_Available`) VALUES
(1, 97572045, 250),
(2, 33019053, 350),
(3, 68861817, 65),
(6, 454777, 245),
(7, 87053266, 1000),
(8, 41780982, 400),
(10, 71513137, 550),
(11, 18989005, 300),
(12, 64441122, 500),
(14, 45889428, 100),
(15, 9891343, 250),
(16, 4414065, 500),
(17, 44076538, 50),
(18, 41902289, 195),
(19, 89858255, 520),
(20, 14501455, 100),
(21, 34087346, 200),
(22, 82888380, 300),
(23, 42265310, 800),
(25, 96854656, 1100);

-- --------------------------------------------------------

--
-- Structure de la table `leaving_stock`
--

CREATE TABLE `leaving_stock` (
  `Id_Stock` int(11) NOT NULL,
  `Id_Product` int(11) DEFAULT NULL,
  `Qty_Out` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `leaving_stock`
--

INSERT INTO `leaving_stock` (`Id_Stock`, `Id_Product`, `Qty_Out`) VALUES
(1, 97572045, 500),
(2, 33019053, 400),
(3, 68861817, 440),
(6, 454777, 750),
(7, 87053266, 500),
(8, 41780982, 600),
(10, 71513137, 950),
(11, 18989005, 200),
(12, 64441122, 500),
(14, 45889428, 400),
(15, 9891343, 750),
(16, 4414065, 1000),
(17, 44076538, 700),
(18, 41902289, 800),
(19, 89858255, 480),
(20, 14501455, 400),
(21, 34087346, 800),
(22, 82888380, 200),
(23, 42265310, 700),
(25, 96854656, 400);

-- --------------------------------------------------------

--
-- Structure de la table `mr`
--

CREATE TABLE `mr` (
  `Date_` date DEFAULT NULL,
  `Report` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Déchargement des données de la table `mr`
--

INSERT INTO `mr` (`Date_`, `Report`) VALUES
('0000-00-00', 'Test'),
('2023-01-20', 'Test'),
('2023-01-20', 'test2'),
('2023-01-22', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `Order_id` int(11) NOT NULL,
  `id_admin` int(11) DEFAULT NULL,
  `id_supp` int(11) DEFAULT NULL,
  `id_product` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `amount` int(11) GENERATED ALWAYS AS (`price` * `quantity`) VIRTUAL,
  `Status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`Order_id`, `id_admin`, `id_supp`, `id_product`, `quantity`, `price`, `Status`) VALUES
(1, 5325883, 48032954, 87053266, 1500, 4, NULL),
(2, 5325883, 48032954, 71513137, 1500, 10, NULL),
(3, 5325883, 48032954, 96854656, 1500, 2, NULL),
(4, 5325883, 48032954, 42265310, 1500, 6, NULL),
(5, 5325883, 48032954, 4414065, 1500, 4, NULL),
(6, 63135222, 89121310, 454777, 1000, 11, NULL),
(7, 63135222, 89121310, 41780982, 1000, 6, NULL),
(8, 63135222, 89121310, 9891343, 1000, 10, NULL),
(9, 63135222, 89121310, 34087346, 1000, 7, NULL),
(10, 98617584, 29204387, 68861817, 500, 5, NULL),
(11, 98617584, 29204387, 14501455, 500, 6, NULL),
(12, 98617584, 29204387, 82888380, 500, 2, NULL),
(13, 98617584, 29204387, 45889428, 500, 4, NULL),
(14, 5325883, 36176900, 33019053, 750, 3, NULL),
(15, 5325883, 36176900, 18989005, 500, 9, NULL),
(16, 5325883, 36176900, 41902289, 1000, 10, NULL),
(17, 5325883, 36176900, 89858255, 1000, 1, NULL),
(18, 5325883, 36176900, 64441122, 1000, 10, NULL),
(19, 63135222, 33013337, 44076538, 750, 11, NULL),
(20, 63135222, 33013337, 97572045, 750, 17, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `outward`
--

CREATE TABLE `outward` (
  `ID_Product` int(11) NOT NULL,
  `Name_Product` varchar(30) DEFAULT NULL,
  `Qty_Sent` int(11) DEFAULT NULL,
  `ID_Customer` int(10) DEFAULT NULL,
  `Name_Customer` varchar(30) NOT NULL,
  `Service_Rating` decimal(5,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `outward`
--

INSERT INTO `outward` (`ID_Product`, `Name_Product`, `Qty_Sent`, `ID_Customer`, `Name_Customer`, `Service_Rating`) VALUES
(454777, 'Doritos', 750, 27198160, 'Gordon W. Matthews', '4'),
(4414065, 'M&M\'s', 1000, 14089742, 'Thomas M. Schuyler', '5'),
(5616398, 'Kit Kat', 1000, 9687379, 'Thomas A. Edwards', '4'),
(9891343, 'Lay\'s Chips', 750, 92937243, 'Thomas M. Mowery', '5'),
(14501455, 'Planters', 400, 28601663, 'Donnie C. Trejo', '4'),
(18989005, 'Jif', 200, 24667219, 'Justin C. Hunt', '5'),
(20190965, 'Kellogg\'s', 300, 54932503, 'Richard D. Velez', '4'),
(33019053, 'Campbell\'s', 400, 74577058, 'Charles C. Hay', '4'),
(33767078, 'Ghirardelli', 750, 68314507, 'Jonathan D. Nees', '5'),
(34087346, 'Pringles', 800, 83069993, 'Erick K. Burgess', '5'),
(41780982, 'Fritos', 600, 96991843, 'Ian M. Wong', '5'),
(41902289, 'Oreo Cookies', 800, 74577058, 'Charles C. Hay', '3'),
(42265310, 'Reese\'s', 700, 50322196, 'Harold M. Lambdin', '5'),
(44076538, 'Nestlé Toll House', 700, 57309244, 'Benjamin E. Battle', '5'),
(45889428, 'Tostitos', 400, 54932503, 'Richard D. Velez', '5'),
(64441122, 'Ritz', 500, 96991843, 'Ian M. Wong', '5'),
(67817617, 'Cheez-It', 600, 83069993, 'Erick K. Burgess', '4'),
(68861817, 'Cheerios', 440, 2724057, 'David L. Johnson', '2'),
(71513137, 'Hershey\'s', 950, 5020214, 'Jules D. Apodaca', '5'),
(75174929, 'Cheetos', 450, 28601663, 'Donnie C. Trejo', '3'),
(82888380, 'Quaker', 200, 27198160, 'Gordon W. Matthews', '4'),
(87053266, 'Dove', 500, 50322196, 'Harold M. Lambdin', '5'),
(89858255, 'Pillsbury', 480, 2724057, 'David L. Johnson', '5'),
(96854656, 'Snickers', 400, 68314507, 'Jonathan D. Nees', '4'),
(97572045, 'Betty Crocker', 500, 57309244, 'Benjamin E. Battle', '4');

-- --------------------------------------------------------

--
-- Structure de la table `persons`
--

CREATE TABLE `persons` (
  `Date` date DEFAULT NULL,
  `Management_Report` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structure de la table `product`
--

CREATE TABLE `product` (
  `ID_Product` int(11) NOT NULL,
  `Name_Product` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `product`
--

INSERT INTO `product` (`ID_Product`, `Name_Product`) VALUES
(454777, 'Doritos'),
(4414065, 'M&M\'s'),
(5616398, 'Kit Kat'),
(9891343, 'Lay\'s Chips'),
(14501455, 'Planters'),
(18989005, 'Jif'),
(20190965, 'Kellogg\'s'),
(33019053, 'Campbell\'s'),
(33767078, 'Ghirardelli'),
(34087346, 'Pringles'),
(41780982, 'Fritos'),
(41902289, 'Oreo Cookies'),
(42265310, 'Reese\'s'),
(44076538, 'Nestlé Toll House'),
(45889428, 'Tostitos'),
(64441122, 'Ritz'),
(67817617, 'Cheez-It'),
(68861817, 'Cheerios'),
(71513137, 'Hershey\'s'),
(75174929, 'Cheetos'),
(82888380, 'Quaker'),
(87053266, 'Dove'),
(89858255, 'Pillsbury'),
(96854656, 'Snickers'),
(97572045, 'Betty Crocker');

-- --------------------------------------------------------

--
-- Structure de la table `receive_inward`
--

CREATE TABLE `receive_inward` (
  `ID_Worker` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL,
  `Reception_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `return_`
--

CREATE TABLE `return_` (
  `ID_Product` int(11) NOT NULL,
  `Name_Product` varchar(30) DEFAULT NULL,
  `Prob4Return` varchar(30) DEFAULT NULL,
  `Returned_Qty` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `return_`
--

INSERT INTO `return_` (`ID_Product`, `Name_Product`, `Prob4Return`, `Returned_Qty`) VALUES
(41902289, 'Oreo Cookies', 'customer problem', 5),
(68861817, 'Cheerios', 'customer problem', 5),
(75174929, 'Cheetos', 'worker fault', 10);

-- --------------------------------------------------------

--
-- Structure de la table `send_outward`
--

CREATE TABLE `send_outward` (
  `ID_Worker` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL,
  `Sending_Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `send_outward`
--

INSERT INTO `send_outward` (`ID_Worker`, `ID_Product`, `Sending_Date`) VALUES
(12534947, 14501455, '2022-03-31'),
(12534947, 96854656, '2022-06-30'),
(14647132, 33019053, '2022-10-21'),
(14647132, 64441122, '2022-02-28'),
(21072972, 454777, '2022-03-21'),
(21072972, 44076538, '2022-09-22'),
(21072972, 97572045, '2022-04-29'),
(36084308, 9891343, '2022-04-29'),
(37917433, 18989005, '2022-04-24'),
(37917433, 82888380, '2022-09-12'),
(37917433, 97572045, '2022-04-29'),
(38819093, 4414065, '2022-01-27'),
(64975793, 42265310, '2022-02-14'),
(64975793, 68861817, '2022-06-25'),
(72437083, 41902289, '2022-02-17'),
(72437083, 87053266, '2022-09-19'),
(77395878, 34087346, '2022-05-19'),
(77395878, 71513137, '2022-02-11'),
(96558639, 41780982, '2022-05-30'),
(96558639, 89858255, '2022-02-26');

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

CREATE TABLE `stock` (
  `ID_Stock` int(11) NOT NULL,
  `ID_Inventory` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `stock`
--

INSERT INTO `stock` (`ID_Stock`, `ID_Inventory`, `ID_Product`) VALUES
(1, 1, 97572045),
(2, 1, 33019053),
(3, 1, 68861817),
(4, 1, 75174929),
(5, 1, 67817617),
(6, 1, 454777),
(7, 1, 87053266),
(8, 1, 41780982),
(9, 1, 33767078),
(10, 1, 71513137),
(11, 1, 18989005),
(12, 1, 64441122),
(13, 1, 5616398),
(14, 1, 45889428),
(15, 1, 9891343),
(16, 1, 4414065),
(17, 1, 44076538),
(18, 1, 41902289),
(19, 1, 89858255),
(20, 1, 14501455),
(21, 1, 34087346),
(22, 1, 82888380),
(23, 1, 42265310),
(24, 1, 20190965),
(25, 1, 96854656);

-- --------------------------------------------------------

--
-- Structure de la table `supplier`
--

CREATE TABLE `supplier` (
  `ID_Supp` int(11) NOT NULL,
  `Name_Supp` varchar(30) DEFAULT NULL,
  `E_mail` varchar(30) DEFAULT NULL,
  `Phone` int(11) DEFAULT NULL,
  `Adress` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `supplier`
--

INSERT INTO `supplier` (`ID_Supp`, `Name_Supp`, `E_mail`, `Phone`, `Adress`) VALUES
(29204387, 'Jim A. Galliher', 'JimAGalliher@rhyta.com', 249384237, '44 Woerdens Road WYBONG NSW 23'),
(33013337, 'Jonathan J. Rios', 'JonathanJRios@rhyta.com', 890343446, '69 Darwinia Loop MCBEATH WA 67'),
(36176900, 'Benjamin L. Morelli', 'benjaminlmorelli@superrito.com', 893615772, '79 Chatsworth Drive KARRAGULLE'),
(48032954, 'John L. Ventura', 'JohnLVentura@dayrep.com', 733418398, '7 Kintyre Street CAMP HILL QLD'),
(89121310, 'Frank C. Murray', 'FrankCMurray@rhyta.com', 397827774, '68 Hebbard Street BANGHOLME VI');

-- --------------------------------------------------------

--
-- Structure de la table `supplier_reception`
--

CREATE TABLE `supplier_reception` (
  `ID_Supp` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL,
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `supplier_supplying`
--

CREATE TABLE `supplier_supplying` (
  `ID_Supp` int(11) NOT NULL,
  `ID_Product` int(11) NOT NULL,
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `worker`
--

CREATE TABLE `worker` (
  `ID_Worker` int(11) NOT NULL,
  `Name_Worker` varchar(30) DEFAULT NULL,
  `E_mail` varchar(30) DEFAULT NULL,
  `Phone` int(11) DEFAULT NULL,
  `Adress` varchar(30) DEFAULT NULL,
  `Password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `worker`
--

INSERT INTO `worker` (`ID_Worker`, `Name_Worker`, `E_mail`, `Phone`, `Adress`, `Password`) VALUES
(12534947, 'William C. Seaborn', 'WilliamCSeaborn@rhyta.com', 394309114, '55 Nerrigundah Drive\r\nLYNDHURS', 'mdZ$=6P9s-'),
(14647132, 'Jeffrey K. Martin', 'JeffreyKMartin@jourrapide.com', 883481638, '57 Wigley Street SOUTH BRIGHTO', 'x9UA4!dB7G'),
(21072972, 'Steven M. Stroble', 'StevenMStroble@armyspy.com', 753491984, '13 Elizabeth Street UPPER GLAS', '&7@P\'v!Tw$'),
(36084308, 'Mark G. Richter', 'MarkGRichter@rhyta.com', 883275931, '21 Thule Drive GREENOCK SA 536', '*D/vy6CbrX '),
(37917433, 'Brandon R. Holloman', 'BrandonRHolloman@dayrep.com', 261492437, '90 Monteagle Road PIERCES CREE', 'Z~7eyMQZHq'),
(38819093, 'Ron G. Pilgrim', 'RonGPilgrim@teleworm.us', 890816274, '95 Banksia Street MILING WA 65', 'Fk8Ku6H],k'),
(64975793, 'Larry L. Gardner', 'LarryLGardner@jourrapide.com', 247589962, '53 Cambridge Street NORTH RICH', 'XA7h&Bd.F*'),
(72437083, 'Thomas P. Symonds', 'ThomasPSymonds@rhyta.com', 240857242, '57 Sydney Road WILPINJONG NSW ', 'AA+7}~ka!t'),
(77395878, 'Willie M. Hinkle', 'WillieMHinkle@teleworm.us', 890395109, '19 Bellion Drive EAGLE BAY WA ', 'WB6M\'@VXnP'),
(96558639, 'Victor C. High', 'VictorCHigh@jourrapide.com', 890733012, '8 Darwinia Loop OOMBULGURRI WA', 'e2(/hQbp9)');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID_Admin`);

--
-- Index pour la table `availableproduct`
--
ALTER TABLE `availableproduct`
  ADD PRIMARY KEY (`ID_Product`);

--
-- Index pour la table `check_defective`
--
ALTER TABLE `check_defective`
  ADD PRIMARY KEY (`ID_Worker`,`ID_Product`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `check_return`
--
ALTER TABLE `check_return`
  ADD PRIMARY KEY (`ID_Worker`,`ID_Product`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`ID_Admin`,`ID_Worker`),
  ADD KEY `ID_Worker` (`ID_Worker`);

--
-- Index pour la table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`ID_Customer`);

--
-- Index pour la table `customer_reception`
--
ALTER TABLE `customer_reception`
  ADD PRIMARY KEY (`ID_Customer`,`ID_Product`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `defective`
--
ALTER TABLE `defective`
  ADD PRIMARY KEY (`ID_Product`);

--
-- Index pour la table `entering_stock`
--
ALTER TABLE `entering_stock`
  ADD PRIMARY KEY (`Id_Stock`);

--
-- Index pour la table `intward`
--
ALTER TABLE `intward`
  ADD PRIMARY KEY (`ID_Product`);

--
-- Index pour la table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`ID_Inventory`);

--
-- Index pour la table `in_stock`
--
ALTER TABLE `in_stock`
  ADD PRIMARY KEY (`id_stock`);

--
-- Index pour la table `leaving_stock`
--
ALTER TABLE `leaving_stock`
  ADD PRIMARY KEY (`Id_Stock`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_id`),
  ADD KEY `id_admin` (`id_admin`),
  ADD KEY `id_supp` (`id_supp`),
  ADD KEY `id_product` (`id_product`);

--
-- Index pour la table `outward`
--
ALTER TABLE `outward`
  ADD PRIMARY KEY (`ID_Product`);

--
-- Index pour la table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ID_Product`);

--
-- Index pour la table `receive_inward`
--
ALTER TABLE `receive_inward`
  ADD PRIMARY KEY (`ID_Worker`,`ID_Product`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `return_`
--
ALTER TABLE `return_`
  ADD PRIMARY KEY (`ID_Product`);

--
-- Index pour la table `send_outward`
--
ALTER TABLE `send_outward`
  ADD PRIMARY KEY (`ID_Worker`,`ID_Product`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`ID_Stock`),
  ADD KEY `ID_Inventory` (`ID_Inventory`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`ID_Supp`);

--
-- Index pour la table `supplier_reception`
--
ALTER TABLE `supplier_reception`
  ADD PRIMARY KEY (`ID_Supp`,`ID_Product`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `supplier_supplying`
--
ALTER TABLE `supplier_supplying`
  ADD PRIMARY KEY (`ID_Supp`,`ID_Product`),
  ADD KEY `ID_Product` (`ID_Product`);

--
-- Index pour la table `worker`
--
ALTER TABLE `worker`
  ADD PRIMARY KEY (`ID_Worker`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `availableproduct`
--
ALTER TABLE `availableproduct`
  ADD CONSTRAINT `availableproduct_ibfk_1` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `check_defective`
--
ALTER TABLE `check_defective`
  ADD CONSTRAINT `check_defective_ibfk_1` FOREIGN KEY (`ID_Worker`) REFERENCES `worker` (`ID_Worker`),
  ADD CONSTRAINT `check_defective_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `check_return`
--
ALTER TABLE `check_return`
  ADD CONSTRAINT `check_return_ibfk_1` FOREIGN KEY (`ID_Worker`) REFERENCES `worker` (`ID_Worker`),
  ADD CONSTRAINT `check_return_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `contract`
--
ALTER TABLE `contract`
  ADD CONSTRAINT `contract_ibfk_1` FOREIGN KEY (`ID_Admin`) REFERENCES `admin` (`ID_Admin`),
  ADD CONSTRAINT `contract_ibfk_2` FOREIGN KEY (`ID_Worker`) REFERENCES `worker` (`ID_Worker`);

--
-- Contraintes pour la table `customer_reception`
--
ALTER TABLE `customer_reception`
  ADD CONSTRAINT `customer_reception_ibfk_1` FOREIGN KEY (`ID_Customer`) REFERENCES `customer` (`ID_Customer`),
  ADD CONSTRAINT `customer_reception_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `defective`
--
ALTER TABLE `defective`
  ADD CONSTRAINT `defective_ibfk_1` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `entering_stock`
--
ALTER TABLE `entering_stock`
  ADD CONSTRAINT `entering_stock_ibfk_1` FOREIGN KEY (`Id_Stock`) REFERENCES `stock` (`ID_Stock`);

--
-- Contraintes pour la table `intward`
--
ALTER TABLE `intward`
  ADD CONSTRAINT `intward_ibfk_1` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `in_stock`
--
ALTER TABLE `in_stock`
  ADD CONSTRAINT `in_stock_ibfk_1` FOREIGN KEY (`id_stock`) REFERENCES `stock` (`ID_Stock`);

--
-- Contraintes pour la table `leaving_stock`
--
ALTER TABLE `leaving_stock`
  ADD CONSTRAINT `leaving_stock_ibfk_1` FOREIGN KEY (`Id_Stock`) REFERENCES `stock` (`ID_Stock`);

--
-- Contraintes pour la table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `admin` (`ID_Admin`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`id_supp`) REFERENCES `supplier` (`ID_Supp`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`id_product`) REFERENCES `availableproduct` (`ID_Product`);

--
-- Contraintes pour la table `outward`
--
ALTER TABLE `outward`
  ADD CONSTRAINT `outward_ibfk_1` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `receive_inward`
--
ALTER TABLE `receive_inward`
  ADD CONSTRAINT `receive_inward_ibfk_1` FOREIGN KEY (`ID_Worker`) REFERENCES `worker` (`ID_Worker`),
  ADD CONSTRAINT `receive_inward_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `return_`
--
ALTER TABLE `return_`
  ADD CONSTRAINT `return__ibfk_1` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `send_outward`
--
ALTER TABLE `send_outward`
  ADD CONSTRAINT `send_outward_ibfk_1` FOREIGN KEY (`ID_Worker`) REFERENCES `worker` (`ID_Worker`),
  ADD CONSTRAINT `send_outward_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `stock`
--
ALTER TABLE `stock`
  ADD CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`ID_Inventory`) REFERENCES `inventory` (`ID_Inventory`),
  ADD CONSTRAINT `stock_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `supplier_reception`
--
ALTER TABLE `supplier_reception`
  ADD CONSTRAINT `supplier_reception_ibfk_1` FOREIGN KEY (`ID_Supp`) REFERENCES `supplier` (`ID_Supp`),
  ADD CONSTRAINT `supplier_reception_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);

--
-- Contraintes pour la table `supplier_supplying`
--
ALTER TABLE `supplier_supplying`
  ADD CONSTRAINT `supplier_supplying_ibfk_1` FOREIGN KEY (`ID_Supp`) REFERENCES `supplier` (`ID_Supp`),
  ADD CONSTRAINT `supplier_supplying_ibfk_2` FOREIGN KEY (`ID_Product`) REFERENCES `product` (`ID_Product`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
