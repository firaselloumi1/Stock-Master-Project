<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Stock Master - Landing Page</title>
  <link href="stock-Master.css" rel="stylesheet" >
  <link rel="icon" href="https://st3.depositphotos.com/7109552/12601/v/950/depositphotos_126016602-stock-illustration-checkmark-inside-gear-green-symbol.jpg">

</head>

<body id="top">
  <script>
  
 
function redirReg(){
 
window.location = "http://localhost/RegistrationPage.php";
 
}
function redirLog(){
 
window.location = "http://localhost/LoginPage.php";
 
}

</script>

  <header id="shadow">
    <a id="invento" href="#top">
      <img class="header" id="logo" src="https://us.123rf.com/450wm/stockgiu/stockgiu2202/stockgiu220200984/stockgiu220200984.jpg?ver=6">
      <h1 class="header" style="font-size: 40px;">Stock Master</h1>
    </a>
    <nav class="header">
            <ul>
              <li> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </li>  
              <li><a style="color:black; font-weight: bold; font-size: 30px;" href="#filler" > &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  About Us </a></li>
              <li><a style="color:black;font-weight: bold; font-size: 30px;"  href="#account">Log in / Register </a></li>
            </ul>
    </nav>
  </header>

  <section id="first">
    <img class="aboutus" src="https://cdn.techgyd.com/UX-Design-1.jpg">
    <div class="aboutus" id="intro">
      <h2>Welcome to our inventory management system for optimal organization and efficiency</h2>
      <center><h4></h4></center> <br>
      <a  id="why" href="#filler">Why Choose Us ?</a>
    </div>
  </section>

   
  <div id="filler">
    <div class="filler"><br> <br> <br> <br> </div>
    <img class="aesthetic" src="">
  </div>
  <section id="offer">
    <center>
      <h2>Stock Master allows you to :</h2>
      <div class="off">
        <a href="#account"> <img title="Gallery ⚠️ Must Login First" src="https://manufacturing-software-blog.mrpeasy.com/wp-content/uploads/2022/08/co-packing-contract-packing.jpg" onclick="alert('Please login first!')" > </a> <br>
        <p>Keeps track of stock levels, reorder points, and stock quantities </p>
      </div>
      <div class="off">
        <a href="#account"> <img title="Publish ⚠️ Must Login First" src="https://manufacturing-software-blog.mrpeasy.com/wp-content/uploads/2021/06/Barcodes-vs-QR-codes.jpg" onclick="alert('Please login first!')" > </a> <br>
        <p>allows for barcode and QR code scanning to efficiently manage inventory, track orders, and process transactions..        </p>
      </div>
      <div class="off">
        <a href="#account"><img title="Feedback ⚠️ Must Login First" src="https://manufacturing-software-blog.mrpeasy.com/wp-content/uploads/2022/08/MrPeasy-Purchase-Order-Management-smaller1.jpg" onclick="alert('Please login first!')" ></a> 
        <p>Allows users to create, process and track orders, including purchase orders, sales orders, and transfer orders. </p>
      </div>
    </center>
  </section>

  <section id="account">
    <div class="filler"><br> <br> <br> <br> </div>
    <center><a class="warning" href="#account" onclick="redirLog()">  ⇩ In order to access the remaining services, please log in ⇩  </a> </center> <br><br>
    <center><a  onclick="redirReg()" class="warning">⇩ You don't have an account yet ? Consider registering ! ⇩</a> </center> 


  <div class="filler"><br> <br> <br> <br> </div>
  <footer>
    <br>
    Firas Elloumi , Trabelsi Hazem | ©TBS_2022 | CS220
    <br> <hr> <hr>
  </footer>

 

</body>
  </html>