
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <title>Stock Master - Customer Page</title>
  <link href="stock-Master.css" rel="stylesheet" >
  <link rel="icon" href="https://st3.depositphotos.com/7109552/12601/v/950/depositphotos_126016602-stock-illustration-checkmark-inside-gear-green-symbol.jpg">

</head>

<body id="top">
    <style>
      table {
        border-collapse: collapse;
      }
      table td,
      table th {
        border: 2px solid #000;
      }
      table tr:first-child th {
        border-top: 0;
      }
      table tr:last-child td {
        border-bottom: 0;
      }
      table tr td:first-child,
      table tr th:first-child {
        border-left: 0;
      }
      table tr td:last-child,
      table tr th:last-child {
        border-right: 0;
      }
    </style>
  <script>
  function redirLand(){
 
window.location = "http://localhost/Stock-Master.php";
 
}

</script>


  <header id="shadow">
    <a id="invento" href="#top">
      <img class="header" id="logo" src="https://us.123rf.com/450wm/stockgiu/stockgiu2202/stockgiu220200984/stockgiu220200984.jpg?ver=6">
      <h1 class="header" onclick="redirLand()" style="color:black;font-weight: bold; font-size: 35px;">Stock Master</h1>
    </a>
<nav class="header">
            <ul>
              <li> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </li>  
              <li> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; </li>
              <li><a style="color:black;font-weight: bold; font-size: 30px; > href="#account">Customer Page</a></li> 
            </ul>
    </nav>
  </header>
<br> <br> <br> <br> <br> <br> <br> <br> 
 <center><div class="filler" style="border: 1px solid black; padding: 5px; font-size:25px;" ><br> <br> <br> <br> 
  <a class="functions"  > Hello Customer ! </a> </<br><br>
  <form method="POST">
  <select name="Functions" style="font-size:25px;" >
  <option selected disabled > --- Select --- </option>
  <option value="Change the password">Change the password </option>
  <option value="View information of different items and their available quantity">View information of different items and their available quantity</option>
  <option value="view management reports">view management reports</option> 
</select>   
<input type="submit" style="border: 1px solid black; padding: 5px; font-size:18px;" name="submit" value="start function"/><br><br><br>
</form>
<?php
if (isset($_POST['submit'])){
if ($_POST['Functions']== "Change the password")
{header("location:customerchangepassword.php");}
if ($_POST['Functions']== "View information of different items and their available quantity")
{$conn=mysqli_connect("localhost","root","", "test");
if (!$conn)
{die("Connection failed: " . mysqli_connect_error());}
$req = "SELECT * FROM availableproduct";
$res = mysqli_query($conn,$req);
if (mysqli_num_rows($res) > 0) {
While($line = mysqli_fetch_assoc($res))
{echo '<table style="font-size:50%;">';
  echo "<colgroup>";
  echo  "<col style='width: 33%'/>";
    echo"<col style='width: 33%' />";
    echo"<col style='width: 33%' />";
  echo"</colgroup>";
echo "<tr>";
echo "<td >", "Product ID: ". $line['ID_Product'] ,"</td>";
echo "<td>", "Product Name: ". $line['Name_Product'] ,"</td>";
echo "<td>", "Max_Qty: ". $line['Max_Qty'] ,"</td>";
echo "<td>", "Min_Qty: ". $line['Min_Qty'] ,"</td>";
echo "<td>", "Production_Date: ". $line['Production_Date'] ,"</td>";
echo "<td>", "Last_Consumption_Date: ". $line['Last_Consumption_Date'] ,"</td>";
echo "<td>", "Qty_Received: ". $line['Qty_Received'] ,"</td>";
echo "<td>", "Qty_Sent: ". $line['Qty_Sent'] ,"</td>";
echo "<td>", "Qty_Available: ". $line['Qty_Available'] ,"</td>";
echo "<td>", "Order_Status: ". $line['Order_Status'] ,"</td>";
echo "<td>", "Qty_Defective: ". $line['Qty_Defective'] ,"</td>";
echo "<td>", "Qty_Returned: ". $line['Qty_Returned'] ,"</td>";
echo "<td>", "Qty_To_Order: ". $line['Qty_To_Order'] ,"</td>";
echo "</tr>";
echo '</table>';
}}
else {echo "0 results";}
mysqli_close($conn);}
if ($_POST['Functions']== "view management reports")
{$conn=mysqli_connect("localhost","root","", "test");
if (!$conn)
{die("Connection failed: " . mysqli_connect_error());}
$req = "SELECT * FROM mr";
$res = mysqli_query($conn,$req);
if (mysqli_num_rows($res) > 0) {
While($line = mysqli_fetch_assoc($res))
{echo '<table style="font-size:100%;">';
  echo "<colgroup>";
  echo  "<col style='width: 33%'/>";
    echo"<col style='width: 33%' />";
    echo"<col style='width: 33%' />";
  echo"</colgroup>";
echo "<tr>";
echo "<td >", "Date: ". $line['Date_'] ,"</td>";
echo "<td>", "Report: ". $line['Report'] ,"</td>";
echo "</tr>";
echo '</table>';
}}
else {echo "0 results";}
mysqli_close($conn);}
}
?>
</div>
</center>



</body>
  </html>